import React from 'react';
import ReactDOM from 'react-dom/client';
import PhotoAlbum from './PhotoAlbum';

const root = ReactDOM.createRoot(document.getElementById('root'));
//root.render(<BrowserRouter>
  //  <Landing/> {/* This is card  */}
            <div class="card card border-primary mb-3" style={{width:"300px",height:"340px"}}>
                   
                   
                  
            <div class="card-body text-center">  
               
                
            </div>
        </div>
    
{/* card ends here */}
//</BrowserRouter>)

root.render(<PhotoAlbum/>)

