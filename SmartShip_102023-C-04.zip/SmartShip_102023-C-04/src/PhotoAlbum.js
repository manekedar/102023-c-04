import React, { useState, useEffect } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

import { Card, Modal, Button, FormControl, InputGroup } from 'react-bootstrap';

function PhotoAlbum() {


  const [photos, setPhotos] = useState([]);

  const [searchQuery, setSearchQuery] = useState('');

  const [selectedPhoto, setSelectedPhoto] = useState(null);
  
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {

                       fetch('https://jsonplaceholder.typicode.com/photos')

         .then((response) => response.json())
      .then((data) => setPhotos(data));

  }, []);

     const handlePhotoClick = (photo) => {

    setSelectedPhoto(photo);

         setShowModal(true);
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
  };

  const filteredPhotos = photos.filter((photo) =>
    photo.title.includes(searchQuery)
  );

  return (
    <div className="container mt-4">
      <InputGroup className="mb-3">
        <FormControl
          placeholder="Search photos by title..."
           value={searchQuery}
          onChange={handleSearch}
        />
      </InputGroup>
      <div className="row">
        {filteredPhotos.map((photo) => (
          <div key={photo.id} className="col-md-3 mb-4">
            <Card onClick={() => handlePhotoClick(photo)}>
              <Card.Img variant="top" src={photo.thumbnailUrl} />
              <Card.Body>
                <Card.Title>
                  {photo.title.length > 20
                    ? photo.title.slice(0, 20) + '...'
                    : photo.title}
                </Card.Title>
              </Card.Body>
            </Card>
          </div>
        ))}
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)}>

        
        <Modal.Header closeButton>
         
          <Modal.Title>Photo Details</Modal.Title>

        </Modal.Header>
        <Modal.Body>
          {selectedPhoto && (
            <div>
              <img
                src={selectedPhoto.url}
                alt={selectedPhoto.title}
                className="img-fluid"
              />
              <p>Title: {selectedPhoto.title}</p>
              <p>Album ID: {selectedPhoto.albumId}</p>
              <p>Photo ID: {selectedPhoto.id}</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default PhotoAlbum;
